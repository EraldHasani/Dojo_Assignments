import React from "react";  
import Navbar from "../components/Navbar";
import DisplayOne from "../components/DisplayOne";
const Details = (props) => {
    return(
        <>
        
            <Navbar />
            
            <DisplayOne/>
            
            
        </>
            
    )
}
export default Details;