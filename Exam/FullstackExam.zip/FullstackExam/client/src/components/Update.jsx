import React,{useState,useEffect} from "react";
import axios from "axios";
import { useNavigate,Link ,useParams} from "react-router-dom";
import "../App.css";

const Update = (props) => {





    return(

         <>

            <h1>Update</h1>

         </>




    )
    }

    export default Update;